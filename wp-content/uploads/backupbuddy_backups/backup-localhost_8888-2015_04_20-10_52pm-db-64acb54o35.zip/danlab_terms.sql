CREATE TABLE `danlab_terms` (  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(200) NOT NULL DEFAULT '',  `slug` varchar(200) NOT NULL DEFAULT '',  `term_group` bigint(10) NOT NULL DEFAULT '0',  PRIMARY KEY (`term_id`),  KEY `slug` (`slug`),  KEY `name` (`name`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `danlab_terms` DISABLE KEYS */;
INSERT INTO `danlab_terms` VALUES('1', 'Uncategorized', 'uncategorized', '0');
INSERT INTO `danlab_terms` VALUES('2', 'Primary Navigation', 'primary-navigation', '0');
/*!40000 ALTER TABLE `danlab_terms` ENABLE KEYS */;
